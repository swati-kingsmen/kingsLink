export const constant = {
  baseUrl:"https://crm-backend-uldu.onrender.com/"
};
